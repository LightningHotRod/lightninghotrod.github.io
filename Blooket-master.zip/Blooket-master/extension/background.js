
chrome.runtime.onInstalled.addListener(() => {
	console.log(`%cSuccessfully loaded Blooket Utilities.`, `color: #ff1975;`);
});