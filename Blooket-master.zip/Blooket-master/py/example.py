import blooket # may need to change based on local path
name = "Goosey";
blooket.login("youremail", "yourpassword"); #  !! this part is required  !!
print(blooket.formatBlookString(name));
