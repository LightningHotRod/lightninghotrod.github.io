# **IMPORTANT**
## **ADDTOKENS MUST BE RAN ON PLAY.BLOOKET.COM NOW!**
**Join the community discord server!** <br>
https://discord.gg/awp325mMNz

##  ALL GUIDE CONTENT HAS BEEN MOVED [TO THE WIKI](https://github.com/GooseterV/Blooket/wiki/)



## Issues & Bugs
- Check for any mistakes you may have made 
- If you are certain it is a problem with the code, go to the [**`Issues`**](https://github.com/GooseterV/Blooket/issues/new) tab of the repo and create a new issue


## Faq

Q. Can I use this on android/ios and how do I?
</br>
A. For IOS please view the IOS/Apple section of this file, for Android/Samsung/Google OS please view the bookmarklet section.
</br>
</br>
Q. When I use any of the Blook scripts, it always gets messed up and displays some info twice. How do i fix this?
</br>
A. Before running the script on the Blooks page, make sure you click on a non-common blook. This happens because the common blooks do not start with a sell price, messing things up.
</br>
</br>
Q. On the export scripts, it always says something goes wrong and fails to copy to clipboard.
</br>
A. This is due to the mozilla clipboard api not being supported on safari, it currently detects anything wrong as an issue and will always download file.
</br>
</br>
**If your question is not listed here anywhere, please feel free to ask in the q/a section of the discussions tab**


